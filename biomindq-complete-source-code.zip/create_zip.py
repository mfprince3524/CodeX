import os
import zipfile

source_dir = r"C:\Users\Farhan\.gemini\antigravity\scratch\biomindq"
output_zip = r"C:\Users\Farhan\.gemini\antigravity\scratch\biomindq\biomindq-complete-source-code.zip"

excluded_dirs = {"node_modules", ".pytest_cache", "__pycache__", ".git"}
excluded_extensions = {".db", ".sqlite3", ".zip"}

with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(source_dir):
        # Exclude directories
        dirs[:] = [d for d in dirs if d not in excluded_dirs]
        for file in files:
            if any(file.endswith(ext) for ext in excluded_extensions):
                continue
            abs_path = os.path.join(root, file)
            rel_path = os.path.relpath(abs_path, source_dir)
            zipf.write(abs_path, rel_path)

print(f"Successfully created zip package at: {output_zip}")
print(f"Package size: {os.path.getsize(output_zip) / (1024*1024):.2f} MB")
